module.exports = {   
    showLogs: true,
    apiKey:"0CM100rK0e9wXIML997UbcSs103LUC4F9110rHgOkpyKpDAAYI110",
  // all other configuration variables apply
    concurrency:30,
    
}