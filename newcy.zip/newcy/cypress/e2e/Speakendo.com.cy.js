/// <reference types="@applitools/eyes-cypress" />
/// <reference types="cypress" />

describe('SPEAKENDO.com', () => {
    beforeEach(() => {
        cy.eyesOpen({
            ignoreDisplacements:true,
            appName: 'Speakendo-sign up Removal- Prod vs Preview1',
            batchName: 'Speakendo-sign up Removal- Prod vs Preview1',
            browser: [

                { width: 1600, height: 900, name: 'chrome' },

                { deviceName: 'iPhone X', screenOrientation: 'portrait', name: 'chrome' },
                { deviceName: 'Galaxy S10 Plus', screenOrientation: 'portrait', name: 'chrome' },
                { deviceName: 'iPad Air 2', screenOrientation: 'portrait' }

            ]
        });
    });
    afterEach(() => {
        cy.eyesClose();
    });
    const url = 'https://www.speakendo.com/'

    it.only('SPEAKENDO', function () {

        cy.visit(url);
        cy.get('.onetrust-close-btn-handler.onetrust-close-btn-ui.banner-close-button.ot-close-icon').click()
        cy.wait(1000);
        cy.eyesCheckWindow('Home page');
    })
    it('SPEAKENDO1', function () {
        //Advertizing Choice
      /*  cy.get('.abbv-modal-open').click();
        cy.wait(1000);
        cy.eyesCheckWindow('WOL');
                  
        cy.get('.wolAdvertisingChoices .abbv-modal-close').click();
     */   //About Endometriosis       
        cy.get('[href="/about-endometriosis"]').contains('About endometriosis').click();
        cy.wait(1500);
        cy.eyesCheckWindow('About Endometriosis page');

        
       
        cy.get('li:nth-child(2) li:nth-child(1) > a').click({ force: true });
        cy.url().should('contains', '/about-endometriosis/what-is-endometriosis');
        cy.eyesCheckWindow('What is Endometriosis page');

        cy.get('.flex-grow-1:nth-child(1) .abbv-modal-open').click();
        cy.wait(1000);
        cy.eyesCheckWindow('Discover the inner workings og Endometriosis pop up');
            
        cy.get('.transcriptModalInnerWorkingsOfEndo .abbv-modal-close').click();

        cy.get('.flex-grow-9 .abbv-modal-open').click();
        cy.wait(1000);
        cy.eyesCheckWindow('Hear from real women with endometriosis pop up');
            
        cy.get('.transcriptHowItsAffectedMe .abbv-modal-close').click();

        //signs and symptoms
       
        cy.get('li:nth-child(2) li:nth-child(2) > a').click({ force: true });
        cy.url().should('contains', '/about-endometriosis/symptoms');
        cy.eyesCheckWindow('Signs & Symptoms page ');
        //Email 

        cy.get('.abbv-share-email').click();
        cy.wait(1000);
        cy.eyesCheckWindow('Email pop up');
        cy.get('.modal:nth-child(4) .abbv-button-primary:nth-child(2)').click();
        cy.eyesCheckWindow('Error message in Email');
        
        cy.get('.globalMailer .abbv-modal-close').click();
        //Where is Endometriosis pain Felt
        cy.get('li:nth-child(2) li:nth-child(3) > a').click({ force: true });
        cy.url().should('contains', '/about-endometriosis/where-is-endometriosis-pain');
       cy.eyesCheckWindow('Where is Endometriosis pain Felt Page');
     
        cy.get('#abbvHotSpotID2 > .abbv-hot-spot-click').click();
        cy.wait(1000);
       cy.eyesCheckWindow('Intestines popup');
        cy.get('#abbvHotSpotID2 .abbv-hot-spot-panel-close').click();
        cy.get('#abbvHotSpotID1 > .abbv-hot-spot-click').click();
        cy.wait(1000);
       cy.eyesCheckWindow('Ovary Popup');
        cy.get('#abbvHotSpotID1 .abbv-hot-spot-panel-close').click();
        cy.get('#abbvHotSpotID3 > .abbv-hot-spot-click').click();
        cy.wait(1000);
       cy.eyesCheckWindow('Bladder popup');
        cy.get('#abbvHotSpotID3 .abbv-hot-spot-panel-close').click();

       //What causes End0metriosis
       
        cy.get('li:nth-child(2) li:nth-child(4) > a').click({ force: true });
        cy.url().should('contains', '/about-endometriosis/causes');
     cy.eyesCheckWindow('What Causes Endometriosis page');
       
        cy.get('.cta > .abbv-modal-open').click();
        cy.wait(1000);
        cy.eyesCheckWindow('Watch this Video pop up');
       
        cy.get('.riskVideoModal .abbv-modal-close').click();

        //Endometriosis Diagnosis
        
        cy.get('li:nth-child(2) li:nth-child(5) > a').click({ force: true });
        cy.url().should('contains', '/about-endometriosis/testing');
        cy.eyesCheckWindow('Endometriosis Diagnosis page');
       
        cy.get('.flex-grow-9 .abbv-modal-open').click();
        cy.wait(1000);
      
        /*cy.eyesCheckWindow({
            target: 'region',
            selector: {
                selector: '.transcriptTrustYourGut',
                type: 'css'
            },
            tag: 'View Transcript Trust gut.Find your voice'
        });*/
        cy.get('.transcriptTrustYourGut .abbv-modal-close').click();

        //Treatment options to Help Endometriosis Pain
       
        cy.get('.abbv-header-primary-navigation-submenu li:nth-child(6) > a').click({ force: true });
        cy.eyesCheckWindow('Treatment options to help Endometriosis pain page');


        //Living With Endometriosis 
        cy.get('[href="/living-with-endometriosis"]').contains('Living with endometriosis').click();
        cy.wait(1000);
        cy.eyesCheckWindow('Living with Endometriosis page');              
        cy.get('li:nth-child(3) li:nth-child(1) > a').click({ force: true });
        cy.eyesCheckWindow('Talking about Endometriosis page')
        cy.get('.flex-grow-9 > .cta > .abbv-modal-open').click();
        cy.wait(1000);
        /*cy.eyesCheckWindow({
            target: 'region',
            selector: {
                selector: '.transcriptBuildRelationshipWithDr',
                type: 'css'
            },
            tag: 'View Transcript-BUILDING A RELATIONSHIP WITH YOUR DOCTOR'
        });
        */
        cy.get('.transcriptBuildRelationshipWithDr .abbv-modal-close').click();
        cy.get('li:nth-child(3) li:nth-child(2) > a').click({ force: true });
       cy.eyesCheckWindow('Tips and Stories page');
        
        cy.get('.abbv-tab-control:nth-child(2) .abbv-tab-text').click();
        cy.wait(1000);
        cy.eyesCheckWindow('Tips and Stories -Daignosis Stories tab');
        cy.get('.abbv-tab-control:nth-child(3) .abbv-tab-text').click();
        cy.wait(1000);
        cy.eyesCheckWindow('Tips and Stories Find the tight doctor');
        cy.get('.abbv-tab-control:nth-child(4) .abbv-tab-text').click();
        cy.wait(1000);
        cy.eyesCheckWindow('Tips and Stories Life with Endo tab');
        cy.get('.mobile-notHid-last .abbv-tab-text').click();
        cy.wait(1000);
        cy.eyesCheckWindow('Tips and Stories Speak up tab');

        //Resources
        cy.get('[href="/endometriosis-resources"]').contains('Resources').click();
        cy.wait(1000);
        cy.eyesCheckWindow('Resources page');       
        cy.get('li:nth-child(4) li:nth-child(1) > a').click({ force: true });
        cy.wait(1000);
       cy.eyesCheckWindow('Symptoms Quiz Page');
               
        cy.get('li:nth-child(4) li:nth-child(1) > a').click({ force: true });
        cy.wait(1000);
       cy.eyesCheckWindow('Find a Gyncologist  Page');

        cy.get('li:nth-child(4) li:nth-child(3) > a').click({ force: true });
        cy.eyesCheckWindow('How to Prepare your Appointment page');
        cy.get('li:nth-child(4) li:nth-child(4) > a').click({ force: true });
        cy.eyesCheckWindow('Video Libraray page');
        cy.get('li:nth-child(4) li:nth-child(5) > a').click({ force: true });
        cy.eyesCheckWindow('Endometriosis Org and Communities');
        //sign up 
        cy.get('#guest-user').click();
        cy.eyesCheckWindow('Sign up page');
        cy.get('.abbv-search').type('Resources');
        cy.get('.abbv-search-navigation > .abbv-icon-search').click()
       cy.eyesCheckWindow('Search Results - Resources criteria');


    })
    it("Sign up iframe symptoms", () => {
       
        cy.visit(url +'/content/speakendo/en-us/endometriosis-resources/symptom-quiz/jcr:content/contentpar/columns_695857689/0/aemform.iframe.en.html?dataRef=&wcmmode=DISABLED');
       cy.eyesCheckWindow('Sign up iframe');
       //Question 1.
        cy.get('#guideContainer-rootPanel-panel1595396691850-panel1556106757901-panel1556521813115-guidetextbox__-1_widget').click();
        cy.wait(500);
        cy.eyesCheckWindow('Question 1.');
        //Next button  //Question 2.
        cy.get('#guideContainer-rootPanel-panel1595396691850-toolbar-nextitemnav___widget').click();
        cy.wait(500);
        cy.eyesCheckWindow('Question 2.');
         //Question 3.
         cy.get('#guideContainer-rootPanel-panel1595396691850-toolbar-nextitemnav___widget').click()
        cy.eyesCheckWindow('Question 3.');
         //Question 4.
         cy.get('#guideContainer-rootPanel-panel1595396691850-toolbar-nextitemnav___widget > .iconButton-label').click()
         cy.wait(500);
         cy.eyesCheckWindow('Question 4.');
          //Question 5.
          cy.get('#guideContainer-rootPanel-panel1595396691850-toolbar-nextitemnav___widget > .iconButton-label').click()
          cy.wait(500);
          cy.eyesCheckWindow('Question 5.');



    })
    it("Sign up prepare-for-your-appointment", () =>{
        cy.visit('https://www.speakendo.com/content/speakendo/en-us/endometriosis-resources/prepare-for-your-appointment/jcr:content/contentpar/columns/0/aemform.iframe.en.html?dataRef=&wcmmode=DISABLED');
        cy.eyesCheckWindow('Sign up prepare-for-your-appointment');

        //Start button
        cy.get('#guideContainer-rootPanel-panel_1607349935-panel-guidebutton___widget').click();
        cy.eyesCheckWindow('Question 1');
        //Has a doctor told you that you have endometriosis?*
        //No button
        cy.get('#guideContainer-rootPanel-panel-panel1556106757901-panel1556521813115-guidetextbox__ > .guideRadioButtonGroupItems > :nth-child(2) > .guideWidgetLabel').click()
        cy.eyesCheckWindow('No button');
        //Next button
        cy.get('#guideContainer-rootPanel-panel-toolbar-nextitemnav___widget > .iconButton-label').click()
        cy.eyesCheckWindow('Question 2');
        //Next button
        cy.get('#guideContainer-rootPanel-panel-toolbar-nextitemnav___widget').click()
        cy.eyesCheckWindow('Question 3');
        //Next button
        cy.get('#guideContainer-rootPanel-panel-toolbar-nextitemnav___widget').click()
        cy.eyesCheckWindow('Question 4');
         //Next button
         cy.get('#guideContainer-rootPanel-panel-toolbar-nextitemnav___widget').click()
         cy.eyesCheckWindow('Question 5');
          //Next button
        cy.get('#guideContainer-rootPanel-panel-toolbar-nextitemnav___widget').click()
        cy.eyesCheckWindow('Question 6');
         //Next button
         cy.get('#guideContainer-rootPanel-panel-toolbar-nextitemnav___widget').click()
         cy.eyesCheckWindow('Question 7');
         //Next button
         cy.get('#guideContainer-rootPanel-panel-toolbar-nextitemnav___widget').click()
         cy.eyesCheckWindow('Question 8');
         //Next button
         cy.get('#guideContainer-rootPanel-panel-toolbar-nextitemnav___widget').click()
         cy.eyesCheckWindow('Question 9');
         //Next button
         cy.get('#guideContainer-rootPanel-panel-toolbar-nextitemnav___widget').click()
         cy.eyesCheckWindow('Question 10');



    })
})
